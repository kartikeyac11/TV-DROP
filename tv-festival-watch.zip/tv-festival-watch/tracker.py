#!/usr/bin/env python3
"""Amazon India festive TV category-minimum monitor via Rainforest API.

The app compares *visible listing prices* across the returned search results,
not checkout/bank/exchange-adjusted costs, and it does not claim all-time lows.
"""
from __future__ import annotations

import json
import os
import re
import sys
import tempfile
import time
from datetime import date, datetime, timezone
from pathlib import Path
from typing import Any

import requests

ROOT = Path(__file__).resolve().parent
STATE_FILE = ROOT / 'data' / 'state.json'
BRANDS = ('Sony', 'Philips', 'LG', 'Samsung')
SIZES = (32, 43)
SALE_START = date(2026, 10, 8)
# Not an official end date: replace via SALE_END_DATE once Amazon announces it.
DEFAULT_PROVISIONAL_END = '2026-11-15'
SEARCH_URL = 'https://api.rainforestapi.com/request'
DISALLOWED = re.compile(
    r'\b(remote|replacement|cover|stand|bracket|mount|protector|case|strip|'
    r'cable|antenna|adapter|motherboard|speaker|soundbar|projector|monitor|'
    r'accessor(?:y|ies)|wall\s*mount|display panel|tv panel|table top)\b',
    re.IGNORECASE,
)
SIZE_PATTERN = {
    32: re.compile(r'(?<!\d)(?:32\s*(?:["”″]|inches?\b|inch\b|in\b)|8[01]\s*cm\b)(?!\d)', re.I),
    43: re.compile(r'(?<!\d)(?:43\s*(?:["”″]|inches?\b|inch\b|in\b)|10[89]\s*cm\b)(?!\d)', re.I),
}
BRAND_PATTERN = {
    'Sony': re.compile(r'\bsony\b', re.I),
    'Philips': re.compile(r'\bphilips\b', re.I),
    'LG': re.compile(r'\blg\b', re.I),
    'Samsung': re.compile(r'\bsamsung\b', re.I),
}
ASIN_PATTERN = re.compile(r'^[A-Z0-9]{10}$')


def group_key(brand: str, size: int) -> str:
    return f'{brand.lower()}-{size}'


def new_state() -> dict[str, Any]:
    return {
        'schema_version': 1,
        'sale': {
            'name': 'Amazon Great Indian Festival 2026',
            'start_date': '2026-10-08',
            'end_date': DEFAULT_PROVISIONAL_END,
            'end_date_confirmed': False,
            'marketplace': 'Amazon.in',
        },
        'last_checked_at': None,
        'categories': {
            group_key(brand, size): {
                'brand': brand, 'size': size, 'status': 'pending', 'current': None,
                'best_ever': None, 'series': [], 'products': [], 'checked_at': None,
                'error': None,
            }
            for size in SIZES for brand in BRANDS
        },
        'alerts': [],
        'pending_notifications': [],
        'check_count': 0,
    }


def read_state(path: Path = STATE_FILE) -> dict[str, Any]:
    if not path.exists():
        return new_state()
    with path.open(encoding='utf-8') as f:
        return json.load(f)


def save_state(state: dict[str, Any], path: Path = STATE_FILE) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(mode='w', dir=path.parent, suffix='.tmp', encoding='utf-8', delete=False) as f:
        json.dump(state, f, indent=2, ensure_ascii=False)
        f.write('\n')
        temp_name = f.name
    os.replace(temp_name, path)


def extract_price(obj: Any) -> float | None:
    """Handle documented Rainforest search_results.price.value and numeric values."""
    if isinstance(obj, dict):
        if obj.get('currency') not in (None, 'INR'):
            return None
        obj = obj.get('value', obj.get('raw'))
    if isinstance(obj, (int, float)) and not isinstance(obj, bool):
        value = float(obj)
    elif isinstance(obj, str):
        cleaned = re.sub(r'[^0-9.]', '', obj)
        try:
            value = float(cleaned)
        except ValueError:
            return None
    else:
        return None
    return round(value, 2) if 2000 <= value <= 5_000_000 else None


def normalize_listing(item: dict[str, Any], brand: str, size: int) -> dict[str, Any] | None:
    title = ' '.join(str(item.get('title', '')).split())
    if not title or not BRAND_PATTERN[brand].search(title):
        return None
    if not re.search(r'\b(tvs?|televisions?|bravia|oled|qled|led|webos)\b', title, re.I):
        return None
    if DISALLOWED.search(title):
        return None
    if not SIZE_PATTERN[size].search(title):
        return None
    # Reject mixed sizes; ambiguous multi-model accessory listings are not TVs.
    if SIZE_PATTERN[43 if size == 32 else 32].search(title):
        return None
    asin = str(item.get('asin', '')).strip().upper()
    if not ASIN_PATTERN.match(asin):
        return None
    price = extract_price(item.get('price'))
    if price is None:
        return None
    availability = item.get('availability') or {}
    availability_txt = availability.get('raw', '') if isinstance(availability, dict) else str(availability)
    if re.search(r'currently unavailable|out of stock|not available', availability_txt, re.I):
        return None
    image = item.get('image')
    if not isinstance(image, str) or not image.startswith('https://'):
        image = None
    return {
        'asin': asin, 'title': title, 'price': price,
        'url': f'https://www.amazon.in/dp/{asin}',
        'image': image,
        'rating': item.get('rating') if isinstance(item.get('rating'), (int, float)) else None,
        'is_prime': bool(item.get('is_prime', False)),
    }


def parse_search_results(payload: dict[str, Any], brand: str, size: int) -> list[dict[str, Any]]:
    """Sort unique matching TVs by price; cheaper search results are considered first."""
    request_info = payload.get('request_info') or {}
    if request_info.get('success') is False:
        raise RuntimeError('Price API reported an unsuccessful search')
    if 'search_results' not in payload:
        raise RuntimeError('Search response has no search_results; cannot conclude no TVs exist')
    seen: dict[str, dict[str, Any]] = {}
    for item in payload['search_results'] or []:
        if not isinstance(item, dict):
            continue
        product = normalize_listing(item, brand, size)
        if product and (product['asin'] not in seen or product['price'] < seen[product['asin']]['price']):
            seen[product['asin']] = product
    return sorted(seen.values(), key=lambda product: (product['price'], product['title']))


def fetch_products(api_key: str, brand: str, size: int, session: requests.Session | None = None) -> list[dict[str, Any]]:
    params = {
        'api_key': api_key,
        'type': 'search', 'amazon_domain': 'amazon.in',
        'search_term': f'{brand} {size} inch smart LED TV television',
        'sort_by': 'price_low_to_high',
        'number_of_results': 30, 'exclude_sponsored': 'true',
    }
    client = session or requests.Session()
    for attempt in range(3):
        try:
            response = client.get(SEARCH_URL, params=params, timeout=55)
            if response.status_code in (429, 500, 502, 503, 504) and attempt < 2:
                time.sleep(2 ** attempt * 4)
                continue
            response.raise_for_status()
            return parse_search_results(response.json(), brand, size)
        except (requests.RequestException, ValueError):
            if attempt == 2:
                raise
            time.sleep(2 ** attempt * 3)
    raise RuntimeError('Unreachable retry termination')


def update_state(
    state: dict[str, Any], checked_at: str,
    scan: dict[str, list[dict[str, Any]]],
    errors: dict[str, str] | None = None,
) -> list[dict[str, Any]]:
    """Update 8 category snapshots and return newly observed category-record alerts."""
    errors = errors or {}
    notifications: list[dict[str, Any]] = []
    for brand in BRANDS:
        for size in SIZES:
            key = group_key(brand, size)
            cat = state['categories'][key]
            if key in errors:
                cat['status'] = 'error'
                cat['error'] = errors[key][:160]
                continue
            if key not in scan:
                continue
            products = scan[key]
            cat['products'] = products[:12]
            cat['checked_at'] = checked_at
            cat['error'] = None
            if not products:
                cat['status'] = 'not_found'
                cat['current'] = None
                continue
            champion = products[0]
            cat['status'] = 'ok'
            cat['current'] = champion
            # The series is category leader price, not same-ASIN price history.
            cat['series'].append({'at': checked_at, 'price': champion['price'], 'asin': champion['asin']})
            cat['series'] = cat['series'][-450:]
            previous_best = cat['best_ever']
            if previous_best is None or champion['price'] < previous_best['price'] - 0.005:
                cat['best_ever'] = {**champion, 'observed_at': checked_at}
                alert = {
                    'id': f'{key}-{checked_at}-{champion["asin"]}',
                    'at': checked_at, 'group': key, 'brand': brand, 'size': size,
                    'price': champion['price'], 'previous_low': previous_best['price'] if previous_best else None,
                    'title': champion['title'], 'url': champion['url'],
                    'type': 'baseline' if previous_best is None else 'new_low',
                }
                notifications.append(alert)
    state['last_checked_at'] = checked_at
    state['check_count'] = state.get('check_count', 0) + 1
    state['alerts'] = (notifications + state.get('alerts', []))[:120]
    state['pending_notifications'] = (state.get('pending_notifications', []) + notifications)[-120:]
    return notifications


def format_inr(price: float) -> str:
    return f'₹{price:,.0f}'


def telegram_message(alerts: list[dict[str, Any]], checked_at: str) -> str:
    if not alerts:
        return ''
    baseline = all(a['type'] == 'baseline' for a in alerts)
    intro = '📺 Festival TV Watch — first observed prices' if baseline else '📉 Festival TV Watch — newly observed category lows'
    lines = [intro, f'Amazon.in • {checked_at[:16].replace("T", " ")} UTC', '']
    for a in alerts:
        movement = f' (was {format_inr(a["previous_low"])})' if a['previous_low'] is not None else ' (baseline)'
        lines.append(f'• {a["brand"]} {a["size"]}″: {format_inr(a["price"])}{movement}')
        lines.append(a['url'])
    lines += ['', 'Observed listing prices; coupon, SBI/card & exchange savings not included.',
              'These are lows since tracking started, not guaranteed historical lows.']
    return '\n'.join(lines)


def send_telegram(token: str, chat_id: str, message: str) -> None:
    result = requests.post(
        f'https://api.telegram.org/bot{token}/sendMessage',
        json={'chat_id': chat_id, 'text': message, 'disable_web_page_preview': True},
        timeout=25,
    )
    result.raise_for_status()
    if not result.json().get('ok'):
        raise RuntimeError('Telegram returned a failed send result')


def main() -> int:
    now = datetime.now(timezone.utc)
    checked_at = now.isoformat(timespec='seconds').replace('+00:00', 'Z')
    local_day = now.astimezone(__import__('zoneinfo').ZoneInfo('Asia/Kolkata')).date()
    state = read_state()
    end_string = os.getenv('SALE_END_DATE', DEFAULT_PROVISIONAL_END)
    try:
        end_date = date.fromisoformat(end_string)
    except ValueError:
        print('SALE_END_DATE must be YYYY-MM-DD', file=sys.stderr)
        return 2
    state['sale']['end_date'] = end_string
    state['sale']['end_date_confirmed'] = os.getenv('SALE_END_CONFIRMED', 'false').lower() == 'true'
    if local_day < SALE_START:
        print(f'Not starting before {SALE_START}')
        return 0
    if local_day > end_date:
        print(f'Sale tracking stopped after configured end date {end_date}')
        save_state(state)
        return 0
    api_key = os.getenv('RAINFOREST_API_KEY', '').strip()
    if not api_key:
        print('RAINFOREST_API_KEY missing: tracking not run', file=sys.stderr)
        return 2
    scanned: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, str] = {}
    with requests.Session() as session:
        for size in SIZES:
            for brand in BRANDS:
                key = group_key(brand, size)
                try:
                    scanned[key] = fetch_products(api_key, brand, size, session)
                    print(f'{key}: {len(scanned[key])} matching TVs' + (f', low={format_inr(scanned[key][0]["price"])}' if scanned[key] else ''))
                except Exception as exc:
                    errors[key] = str(exc)
                    print(f'{key}: error {exc}', file=sys.stderr)
                time.sleep(0.7)
    alerts = update_state(state, checked_at, scanned, errors)
    token = os.getenv('TELEGRAM_BOT_TOKEN', '').strip()
    chat_id = os.getenv('TELEGRAM_CHAT_ID', '').strip()
    state['telegram_enabled'] = bool(token and chat_id)
    save_state(state)
    print(f'Saved {len(alerts)} alerts, {len(errors)} failed queries')
    pending = list(state.get('pending_notifications', []))
    if pending and token and chat_id:
        # Deliver queued alerts in small groups; retain unsent items on API failure.
        for i in range(0, len(pending), 8):
            batch = pending[i:i+8]
            message = telegram_message(batch, checked_at)
            try:
                send_telegram(token, chat_id, message[:4000])
                state['pending_notifications'] = state['pending_notifications'][len(batch):]
                save_state(state)
                print(f'Telegram sent {len(batch)} alerts')
            except Exception as exc:
                print(f'Telegram send failed; alerts queued for the next scan: {exc}', file=sys.stderr)
                return 1
    elif pending:
        print('Telegram notifications disabled: pending alerts queued until credentials are configured')
    return 1 if errors and not scanned else 0


if __name__ == '__main__':
    raise SystemExit(main())
