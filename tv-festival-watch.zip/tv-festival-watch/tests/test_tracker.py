import sys
import unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from tracker import (
    normalize_listing, parse_search_results, group_key, new_state, update_state,
    telegram_message, extract_price,
)


def product(title, price, asin='B0BTV0TEST'):
    return {'title': title, 'asin': asin, 'price': {'currency': 'INR', 'value': price}}


class ParsingTests(unittest.TestCase):
    def test_matches_brand_and_size(self):
        item = product('Samsung 108 cm (43 inches) Crystal 4K Smart LED TV', 22999)
        normalized = normalize_listing(item, 'Samsung', 43)
        self.assertEqual(normalized['price'], 22999)
        self.assertEqual(normalized['url'], 'https://www.amazon.in/dp/B0BTV0TEST')

    def test_rejects_wrong_size(self):
        self.assertIsNone(normalize_listing(product('Samsung 80 cm (32 inches) Smart LED TV', 12000), 'Samsung', 43))

    def test_rejects_brand_and_accessory(self):
        self.assertIsNone(normalize_listing(product('LG 43 inch TV wall mount bracket', 4000), 'LG', 43))
        self.assertIsNone(normalize_listing(product('TCL 43 inch Smart LED TV', 16000), 'LG', 43))

    def test_accepts_80_cm_32_and_108_cm_43(self):
        self.assertIsNotNone(normalize_listing(product('Sony 80 cm HD Ready 32 inch LED Smart TV', 16990), 'Sony', 32))
        self.assertIsNotNone(normalize_listing(product('Philips 108 cm (43 inch) 4K Android TV', 19990), 'Philips', 43))

    def test_rejects_mixed_sizes(self):
        self.assertIsNone(normalize_listing(product('Sony 32 inch and 43 inch Smart LED TV listing', 13500), 'Sony', 32))

    def test_rejects_non_inr_and_invalid_prices(self):
        self.assertIsNone(extract_price({'currency':'USD','value':199.0}))
        self.assertIsNone(extract_price({'currency':'INR','value':100}))
        self.assertEqual(extract_price('₹23,490.00'), 23490)

    def test_dedupe_and_sort(self):
        rows=[product('LG 43 inch LED Smart TV',27000,'B0BTV0TEST'),
              product('LG 43 inch LED Smart TV',26000,'B0BTV0TEST'),
              product('LG 43 inch OLED TV',25000,'B0BTV0TES2'),
              product('LG 43 inch TV remote', 3000,'B0BTV0TES3')]
        result=parse_search_results({'search_results':rows},'LG',43)
        self.assertEqual([r['price'] for r in result],[25000,26000])

    def test_missing_search_results_is_error(self):
        with self.assertRaises(RuntimeError):
            parse_search_results({'request_info':{'success':True}},'LG',43)


class TrackingTests(unittest.TestCase):
    def setUp(self):
        self.state=new_state()
        self.key=group_key('Samsung',43)
        self.tv=lambda price: normalize_listing(product('Samsung 43 inch Smart LED TV',price), 'Samsung', 43)

    def test_initial_baseline_then_record_then_no_duplicate(self):
        first=update_state(self.state,'2026-10-08T07:00:00Z',{self.key:[self.tv(23990)]})
        self.assertEqual(len(first),1)
        self.assertEqual(first[0]['type'],'baseline')
        none=update_state(self.state,'2026-10-08T10:00:00Z',{self.key:[self.tv(23990)]})
        self.assertEqual(none,[])
        lower=update_state(self.state,'2026-10-08T13:00:00Z',{self.key:[self.tv(22990)]})
        self.assertEqual(lower[0]['type'],'new_low')
        self.assertEqual(lower[0]['previous_low'],23990)
        higher=update_state(self.state,'2026-10-08T16:00:00Z',{self.key:[self.tv(23900)]})
        self.assertEqual(higher,[])
        self.assertEqual(self.state['categories'][self.key]['best_ever']['price'],22990)
        self.assertEqual(len(self.state['categories'][self.key]['series']),4)

    def test_empty_and_failed_scans_do_not_create_false_lows(self):
        self.assertEqual(update_state(self.state,'2026-10-08T07:00:00Z',{self.key:[]}),[])
        self.assertEqual(self.state['categories'][self.key]['status'],'not_found')
        self.assertEqual(update_state(self.state,'2026-10-08T10:00:00Z',{},errors={self.key:'429'}),[])
        self.assertEqual(self.state['categories'][self.key]['status'],'error')

    def test_pending_queue_keeps_unsent_alerts(self):
        update_state(self.state,'2026-10-08T07:00:00Z',{self.key:[self.tv(23990)]})
        update_state(self.state,'2026-10-08T10:00:00Z',{self.key:[self.tv(22990)]})
        self.assertEqual(len(self.state['pending_notifications']),2)
        self.assertEqual(self.state['pending_notifications'][0]['type'],'baseline')
        self.assertEqual(self.state['pending_notifications'][1]['type'],'new_low')

    def test_alert_text_includes_price_and_url(self):
        alerts=update_state(self.state,'2026-10-08T07:00:00Z',{self.key:[self.tv(23990)]})
        msg=telegram_message(alerts,'2026-10-08T07:00:00Z')
        self.assertIn('₹23,990',msg)
        self.assertIn('https://www.amazon.in/dp/B0BTV0TEST',msg)

if __name__=='__main__':
    unittest.main()
