# TV DROP — Amazon India Festival TV Price Watch

A dark, mobile-friendly dashboard **and** a scheduled background price checker for 32-inch and 43-inch televisions by **Sony, Philips, LG, and Samsung** on Amazon.in. It stores category-level price history and sends **Telegram messages** when it observes a new low during your own tracking period.

**Created for 8 October 2026.** Amazon confirmed the sale start date, but **not the end date** as of creation. The repository uses **15 November 2026 as a *provisional* stop date**, not as a claim about the official sale schedule. When Amazon announces the end, update the date in GitHub Settings → Secrets and variables → Actions → **Variables** (`SALE_END_DATE`, format `YYYY-MM-DD`). The checker stops **after** that date, using India time. Set `SALE_END_CONFIRMED=true` when known. It will not automatically infer the end date.

## How to activate the live site and notifications (about 10 steps)

1. Create a free GitHub repository, e.g. `tv-drop`. Upload **all project files**, including the hidden `.github/workflows/track.yml` folder and `data/state.json`. Make sure **GitHub Actions** are enabled.
2. Create a **Rainforest API** account (a paid third-party Amazon product-data API) and obtain an API key: [Rainforest documentation](https://docs.trajectdata.com/rainforestapi/product-data-api/parameters/search). The app searches Amazon India through this API instead of scraping pages. The demo does not require an API key.
3. In Telegram, find **@BotFather** → `/newbot` → copy the bot token. **Send your new bot a message** so it can identify your chat.
4. Open `https://api.telegram.org/bot<YOUR_BOT_TOKEN>/getUpdates` in your own browser, substituting your real token. Find `"chat":{"id":12345,...}` in the JSON response. This number is your `TELEGRAM_CHAT_ID`. **Do not share the bot token**. If `result` is empty, message the bot again and reload.
5. In your GitHub repository, go to **Settings → Secrets and variables → Actions → Repository secrets**. Create these three secrets:

   | Secret | Value |
   |---|---|
   | `RAINFOREST_API_KEY` | your API key |
   | `TELEGRAM_BOT_TOKEN` | token from @BotFather |
   | `TELEGRAM_CHAT_ID` | your numeric Telegram chat ID |

6. Optionally, under **Repository variables**, set `SALE_END_DATE=2026-11-15` (provisional, **replace when officially announced**) and `SALE_END_CONFIRMED=false`.
7. Open **Actions → Check Amazon TV prices → Run workflow**. On the **first successful scan**, Telegram sends the **baseline** price for each category that has a matching TV. Later scans notify you only when an **even lower category price** appears. Every 3 hours, GitHub Actions automatically runs another check.
8. Under **Settings → Pages**, choose **Deploy from a branch** → branch `main` → folder `/(root)` → Save. Visit the published GitHub Pages URL. The site loads `data/state.json` from the same repository.
9. Allow browser notifications on the site if you also want tab-open alerts. **Telegram is the reliable off-screen delivery path.** Browser Notifications do not run when the page is closed.
10. When Amazon announces the actual sale end, change the `SALE_END_DATE` Actions variable to that date. The automatic checker will stop the following day (India time).

> **Cost note:** The checker performs **8 Rainforest search requests every 3 hours**, or roughly **1,920 API search requests over 30 days**, before any retries. Review the provider's current paid plan, credits and rate limits first. You can reduce the schedule in `.github/workflows/track.yml` from `11 */3 * * *` to e.g. `11 */6 * * *` (every six hours) to halve normal usage. GitHub Actions cron may run later than its scheduled time.

## What exactly counts as a price drop?

- Each scan searches **8 combinations**: 4 brands × 2 sizes. For each category, it sorts the currently returned qualifying TV listings by the **visible Amazon.in selling price**.
- The first observed category minimum is saved as a **baseline**. If a later scan finds a cheaper qualifying listing in that category, it saves a **new low** and alerts Telegram. It does **not** send a fresh alert merely because a product becomes available again at the same previously observed low.
- The lowest product can **change models** between scans; the chart is the lowest price in the category at each scan, **not** one specific ASIN's history.
- Strict title filters exclude different screen sizes, other brands, mounts, remotes, accessories and monitors. Products with missing/incomplete prices or unverified sizes are skipped. This can miss some real TVs whose titles omit their sizes.
- Amazon's bank discounts, SBI card offers, coupons, exchange credits, delivery fees and final checkout differences are **not** applied. The source is the listed price in the API's search result, not guaranteed checkout cost.
- Results cover the search listings returned by the provider and may not include every Amazon TV, so **"lowest" means the lowest *observed matching search result***, not a verified absolute marketplace minimum or historical all-time low. Prices can change between scans.
- The tracker records only after you enable it. It cannot retroactively reconstruct prices between Oct 8 and your first successful run.

## Local development

```bash
python -m pip install -r requirements.txt
python -m http.server 8080
# visit http://localhost:8080
```

Click **View demo prices** to see a clearly labeled **fictional sample UI**. To test a live scan without GitHub (this **consumes API credits**):

```bash
export RAINFOREST_API_KEY='your-key'
export TELEGRAM_BOT_TOKEN='optional-bot-token'
export TELEGRAM_CHAT_ID='optional-chat-id'
export SALE_END_DATE='2026-11-15'  # provisional
python tracker.py
```

To run the included tests:

```bash
python -m unittest discover -s tests -v
```

## Data and privacy

- Your Rainforest key and Telegram token are used by Python/GitHub Actions and **never exposed to the GitHub Pages JavaScript**. Keep the repository's secret values in GitHub Actions secrets, not `.env` committed to git.
- `data/state.json` is **public** when your repository's site is public. It contains observed product prices, titles and links, *not* your Chat ID or secret tokens.
- GitHub Pages is a static website; it does **not** run the checker. GitHub Actions does. If scheduled Actions stop, new prices/alerts stop too.
- GitHub Actions can be paused by the platform, especially on inactive repositories; verify the Actions tab if prices become stale.
- This is an independent utility, not affiliated with Amazon. Please review the Rainforest API's licensing and Amazon's terms before heavy usage.
