/* TV DROP: static GitHub Pages dashboard; live scans/notifications run in GitHub Actions. */
(() => {
  'use strict';
  const BRANDS = ['Sony', 'Philips', 'LG', 'Samsung'];
  const SIZES = [32, 43];
  const $ = (selector) => document.querySelector(selector);
  const app = {state: null, demo: false, selected: 'samsung-43', size: 'all', brand: 'all', sort: 'brand', hasLoaded: false};
  const fmt = (n) => typeof n === 'number' && Number.isFinite(n) ? '₹' + Math.round(n).toLocaleString('en-IN') : '—';
  const safe = (val) => String(val ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const categoryKey = (brand, size) => `${brand.toLowerCase()}-${size}`;
  const fmtTime = (iso) => {
    if (!iso) return 'Awaiting first scan';
    const d = new Date(iso);
    return Number.isNaN(d.getTime()) ? 'Unknown time' : d.toLocaleString('en-IN', {timeZone:'Asia/Kolkata',day:'numeric',month:'short',hour:'numeric',minute:'2-digit',hour12:true}) + ' IST';
  };
  const fmtShortTime = (iso) => {
    const d = new Date(iso);
    return Number.isNaN(d.getTime()) ? '' : d.toLocaleDateString('en-IN',{timeZone:'Asia/Kolkata',day:'numeric',month:'short'});
  };
  const allCats = () => {
    const cats = (app.state && app.state.categories) || {};
    return SIZES.flatMap(size => BRANDS.map(brand => cats[categoryKey(brand,size)] || {
      brand,size,status:'pending',current:null,best_ever:null,series:[],products:[]
    }));
  };
  const trend = cat => (cat.series?.length && cat.current ? Number(cat.series[0].price) - Number(cat.current.price) : 0);
  const amazonUrl = link => /^https:\/\/www\.amazon\.in\/dp\/[A-Z0-9]{10}$/.test(link||'') ? link : null;

  function cardHtml(cat) {
    const active = app.selected === categoryKey(cat.brand,cat.size);
    const current = cat.current;
    const hasPrice = current && typeof current.price === 'number';
    const delta = trend(cat);
    const count = (cat.products||[]).length;
    const end = hasPrice ? (amazonUrl(current.url) ? `<a class="shop-link" href="${safe(current.url)}" target="_blank" rel="noopener noreferrer" aria-label="View ${safe(cat.brand)} ${cat.size} inch on Amazon">VIEW DEAL ↗</a>` : '') : '<span class="no-shop">NO LINK YET</span>';
    const tag = cat.status === 'error' ? 'CHECK FAILED' : cat.status === 'not_found' ? 'NO MATCH FOUND' : hasPrice ? 'LOWEST RIGHT NOW' : 'AWAITING FIRST SCAN';
    const photo = hasPrice && current.image && /^https:\/\//.test(current.image) ? `<img class="product-photo" src="${safe(current.image)}" loading="lazy" alt="${safe(cat.brand)} television">` : '<div class="mini-screen"></div>';
    let chip = '<span class="flat-chip">No movement yet</span>';
    if (hasPrice && cat.series?.length > 1) {
      chip = delta > 0 ? `<span class="down-chip">↓ ${fmt(delta)} vs first check</span>` : delta < 0 ? `<span class="flat-chip">↑ ${fmt(-delta)} vs first check</span>` : '<span class="flat-chip">Same as first check</span>';
    }
    const best = cat.best_ever?.price;
    return `<article class="price-card ${active ? 'selected':''}" data-key="${safe(categoryKey(cat.brand,cat.size))}" tabindex="0" role="button" aria-pressed="${active}" aria-label="Show ${safe(cat.brand)} ${cat.size} inch price history">
      <div class="card-top"><div class="brand-display ${safe(cat.brand.toLowerCase())}">${safe(cat.brand)}</div><span class="size-badge">${cat.size} INCH</span></div>
      <div class="card-visual">${photo}</div><div class="card-label">${tag}</div><div class="card-price ${hasPrice ? '':'pending'}">${hasPrice ? fmt(current.price) : '—'}</div>
      <div class="card-meta">${chip}<span>${count ? count + ' models' : ''}</span></div>
      <div class="card-product">${hasPrice ? safe(current.title) : cat.status === 'error' ? 'Last search failed. Will retry next check.' : 'No verified listing price yet for this category.'}</div>
      <div class="card-bottom"><span class="card-best">Sale-period low<br><strong>${fmt(best)}</strong></span>${end}</div>
    </article>`;
  }

  function drawCards() {
    let cats = allCats().filter(c => (app.size === 'all' || String(c.size) === app.size) && (app.brand === 'all' || c.brand === app.brand));
    if (app.sort === 'price') cats.sort((a,b) => (a.current?.price ?? Infinity) - (b.current?.price ?? Infinity));
    if (app.sort === 'drop') cats.sort((a,b) => trend(b) - trend(a));
    $('#price-grid').innerHTML = cats.map(cardHtml).join('');
    $('#price-grid').querySelectorAll('.price-card').forEach(card => {
      function select() { app.selected = card.dataset.key; drawCards(); drawDetail(); $('#details-panel').scrollIntoView({behavior:'smooth',block:'start'}); }
      card.addEventListener('click', ev => { if (ev.target.closest('a')) return; select(); });
      card.addEventListener('keydown', ev => { if (ev.key === 'Enter' || ev.key === ' ') {ev.preventDefault();select();} });
    });
  }

  function drawStats() {
    for (const size of SIZES) {
      const leaders = allCats().filter(cat => cat.size === size && typeof cat.current?.price === 'number').sort((a,b)=>a.current.price-b.current.price);
      $(`#stat-${size}`).textContent = leaders.length ? fmt(leaders[0].current.price) : '—';
      $(`#stat-${size}-brand`).textContent = leaders.length ? `${leaders[0].brand} · cheapest currently found` : 'Waiting for first scan';
    }
    const lows = (app.state?.alerts||[]).filter(a=>a.type==='new_low').length;
    $('#stat-alerts').textContent = String(lows).padStart(2,'0');
    $('#stat-checks').textContent = app.state?.check_count ? `${app.state.check_count} completed scans` : 'No price checks yet';
    $('#last-updated').textContent = app.demo ? 'Fictional sample · not live' : (app.state?.last_checked_at ? `Checked ${fmtTime(app.state.last_checked_at)}` : 'Awaiting first scan');
    const sale = app.state?.sale;
    if (sale) {
      const end = sale.end_date ? new Date(sale.end_date+'T12:00:00Z').toLocaleDateString('en-GB',{day:'numeric',month:'short',year:'numeric'}) : 'not set';
      $('#sale-note').innerHTML = `<span class="note-glyph">ⓘ</span><span>${sale.end_date_confirmed ? `Tracking is configured through the <strong>confirmed sale end date of ${safe(end)}</strong>.` : `Amazon has not confirmed a final end date. The tracker currently uses a <strong>provisional ${safe(end)} stop date</strong> that can be updated after announcement.`}</span>`;
    }
    $('#demo-banner').hidden = !app.demo;
    $('#demo-button').textContent = app.demo ? 'Demo prices are shown ✓' : 'View demo prices →';
  }

  function chartSvg(series) {
    const pts = series.filter(point => typeof point.price === 'number');
    if (!pts.length) return '<div class="empty-chart"><div class="empty-wave">⌁</div>No price history yet.<br><span>Checks will populate this chart.</span></div>';
    const W=600,H=235,left=65,right=10,top=20,bottom=35;
    const vals=pts.map(point=>point.price);
    let min=Math.min(...vals), max=Math.max(...vals);
    const pad=Math.max((max-min)*.2,Math.max(max*.035,500));
    min=Math.max(0,min-pad);max=max+pad;
    const X=i=>left+(pts.length===1?(W-left-right)/2:(i/(pts.length-1))*(W-left-right));
    const Y=v=>top+(max-v)/(max-min)*(H-top-bottom);
    const coords=pts.map((p,i)=>`${X(i).toFixed(1)},${Y(p.price).toFixed(1)}`);
    const plot=coords.join(' ');
    const area=`M ${coords[0]} L ${coords.slice(1).join(' L ')} L ${X(pts.length-1).toFixed(1)},${H-bottom} L ${X(0).toFixed(1)},${H-bottom} Z`;
    const lines=[0,.5,1].map(t=>{const y=top+t*(H-top-bottom);const v=max-t*(max-min);return `<line class="chart-gridline" x1="${left}" x2="${W-right}" y1="${y}" y2="${y}"/><text class="chart-axis-label" x="${left-10}" y="${y+4}" text-anchor="end">${safe(fmt(v))}</text>`;}).join('');
    const start=fmtShortTime(pts[0].at),end=fmtShortTime(pts[pts.length-1].at);
    const labels=`<text class="chart-axis-label" x="${left}" y="${H-10}">${safe(start)}</text><text class="chart-axis-label" x="${W-right}" y="${H-10}" text-anchor="end">${safe(end)}</text>`;
    const marker=pts.map((p,i)=>`<circle class="chart-dot" cx="${X(i)}" cy="${Y(p.price)}" r="${i===pts.length-1?5:pts.length<20?3:0}"/>`).join('');
    return `<svg role="img" aria-label="Observed minimum prices from ${safe(start)} to ${safe(end)}" viewBox="0 0 ${W} ${H}" preserveAspectRatio="none"><defs><linearGradient id="priceFill" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#f5ad76" stop-opacity=".23"/><stop offset="1" stop-color="#f5ad76" stop-opacity=".008"/></linearGradient></defs>${lines}${labels}<path class="chart-area" d="${area}"/><polyline class="chart-line" points="${plot}"/>${marker}</svg>`;
  }

  function drawDetail() {
    const cat=allCats().find(c=>categoryKey(c.brand,c.size)===app.selected)||allCats()[0];
    $('#chart-heading').textContent=`${cat.brand} · ${cat.size}″`;
    $('#chart-best').textContent=fmt(cat.best_ever?.price);
    $('#chart-subheading').textContent=cat.series?.length ? `${cat.series.length} saved scans · cheapest matching TV per scan` : 'Category minimum listing price over time';
    $('#history-chart').innerHTML=chartSvg(cat.series||[]);
    const models=cat.products||[];
    $('#other-models').innerHTML=models.length ? models.slice(0,5).map((p,i)=>`<div class="model-row"><span class="model-desc" title="${safe(p.title)}">${i+1}. ${safe(p.title)}</span><span class="model-right"><strong>${fmt(p.price)}</strong>${amazonUrl(p.url)?`<a href="${safe(p.url)}" rel="noopener noreferrer" target="_blank" aria-label="Open product ${safe(p.asin)}">↗</a>`:''}</span></div>`).join(''):'<div class="model-empty">No matching results from the latest scan.</div>';
  }

  function drawActivity() {
    const alerts=app.state?.alerts||[];
    if (!alerts.length) {
      $('#alerts-list').innerHTML='<div class="empty-activity"><span>↘</span><strong>Quiet for now.</strong><p>New observed price lows will appear here after the first scans.</p></div>';
      return;
    }
    $('#alerts-list').innerHTML=alerts.slice(0,12).map(a=>`<div class="alert-item"><span class="alert-mark ${a.type==='baseline'?'baseline':''}">${a.type==='baseline'?'•':'↘'}</span><div class="alert-info"><div class="alert-head"><strong>${safe(a.brand)} ${safe(a.size)}″ · ${fmt(a.price)}</strong><span class="alert-time">${safe(fmtTime(a.at))}</span></div><p>${a.type==='baseline'?'First observed price':`New low${typeof a.previous_low==='number'?` · down ${fmt(a.previous_low-a.price)}`:''}`}</p>${amazonUrl(a.url)?`<a href="${safe(a.url)}" target="_blank" rel="noopener noreferrer">View on Amazon ↗</a>`:''}</div></div>`).join('');
  }

  function render(){drawStats();drawCards();drawDetail();drawActivity();}

  function notifyNewAlerts(nextState){
    if(app.demo||!('Notification' in window)||Notification.permission!=='granted'||!app.hasLoaded||!nextState?.alerts) return;
    const oldIds=new Set((app.state?.alerts||[]).map(a=>a.id));
    const newlyFound=nextState.alerts.filter(a=>a.type==='new_low'&&!oldIds.has(a.id)).slice(0,4);
    for(const alert of newlyFound) {
      try { const n=new Notification(`New low: ${alert.brand} ${alert.size}″ · ${fmt(alert.price)}`,{body:'Amazon India · Lowest observed since tracking began',tag:alert.id}); n.onclick=()=>{window.focus();const u=amazonUrl(alert.url);if(u)window.open(u,'_blank','noopener,noreferrer');}; } catch(e){ /* permission/browser limitation */ }
    }
  }

  async function fetchSavedData(){
    if(app.demo) return;
    $('#refresh-button').textContent='◌';
    try{
      const response=await fetch(`data/state.json?v=${Date.now()}`,{cache:'no-store'});
      if(!response.ok) throw new Error('HTTP '+response.status);
      const data=await response.json();
      if(data.schema_version!==1) throw new Error('Unknown state format');
      notifyNewAlerts(data);
      app.state=data;
      render();
      app.hasLoaded=true;
    }catch(error){
      $('#last-updated').textContent='Unable to read saved prices · use localhost or GitHub Pages';
      console.warn('TV DROP: Could not load data/state.json',error);
    }finally{$('#refresh-button').textContent='↻';}
  }

  function demoState(){
    const prices={'sony-32':17990,'philips-32':10590,'lg-32':11990,'samsung-32':11790,'sony-43':33490,'philips-43':18990,'lg-43':26990,'samsung-43':22990};
    const productTitles={'sony-32':'Sony 80 cm (32 inches) HD Ready Smart LED TV — fictional example','philips-32':'Philips 80 cm (32 inch) HD Ready Smart TV — fictional example','lg-32':'LG 80 cm (32 inches) HD Ready Smart LED TV — fictional example','samsung-32':'Samsung 80 cm (32 inch) Smart LED TV — fictional example','sony-43':'Sony Bravia 108 cm (43 inches) 4K LED Smart TV — fictional example','philips-43':'Philips 108 cm (43 inches) 4K Smart LED TV — fictional example','lg-43':'LG 108 cm (43 inch) 4K UHD Smart TV — fictional example','samsung-43':'Samsung 108 cm (43 inches) Crystal 4K Smart TV — fictional example'};
    const state={schema_version:1,sale:{name:'Amazon Great Indian Festival 2026',start_date:'2026-10-08',end_date:'2026-11-15',end_date_confirmed:false},check_count:6,last_checked_at:new Date().toISOString(),categories:{},alerts:[]};
    let index=0;
    for(const size of SIZES)for(const brand of BRANDS){
      const key=categoryKey(brand,size),price=prices[key],time=Date.now();
      const history=[price+2400,price+1800,price+1900,price+700,price+950,price].map((v,i)=>({price:v,at:new Date(time-(5-i)*3*3600000).toISOString(),asin:'B0EXAMPLE1'}));
      const current={asin:'B0EXAMPLE1',title:productTitles[key],price,url:'',image:null};
      state.categories[key]={brand,size,status:'ok',current,best_ever:{...current,observed_at:new Date().toISOString()},checked_at:new Date().toISOString(),products:[current,{...current,title:productTitles[key].replace(' — fictional example',' — second fictional variant'),price:price+1400}],series:history,error:null};
      if(index%3===0)state.alerts.push({id:key,at:new Date().toISOString(),group:key,brand,size,price,previous_low:price+950,title:current.title,url:'',type:'new_low'});
      index++;
    }
    return state;
  }

  function setupDialog(){const dlg=$('#setup-dialog');if(dlg.showModal)dlg.showModal();else dlg.setAttribute('open','');}
  function init(){
    $('#setup-button').addEventListener('click',setupDialog);
    $('#telegram-setup').addEventListener('click',setupDialog);
    $('#close-setup').addEventListener('click',()=>$('#setup-dialog').close());
    $('#modal-close-bottom').addEventListener('click',()=>$('#setup-dialog').close());
    $('#setup-dialog').addEventListener('click',e=>{if(e.target===$('#setup-dialog'))$('#setup-dialog').close();});
    $('#notifications-button').addEventListener('click',async()=>{
      if(!('Notification' in window)) {alert('Browser notifications are not supported here. Use Telegram notifications for alerts when the tab is closed.');return;}
      if(!window.isSecureContext) {alert('Browser alerts need HTTPS or localhost. Deploy to GitHub Pages to enable them.');return;}
      const permission=await Notification.requestPermission();
      $('#notifications-button').innerHTML=permission==='granted'?'✓ Browser alerts enabled':'◉ Enable browser alerts <span class="btn-arrow">↗</span>';
      if(permission==='denied')alert('Notifications were blocked. You can allow them in your browser site settings.');
    });
    $('#demo-button').addEventListener('click',()=>{if(!app.demo){app.realState=app.state;app.state=demoState();app.demo=true;render();}});
    $('#exit-demo').addEventListener('click',()=>{app.demo=false;app.state=app.realState;render();fetchSavedData();});
    $('#refresh-button').addEventListener('click',fetchSavedData);
    $('#size-controls').querySelectorAll('button').forEach(button=>button.addEventListener('click',()=>{
      app.size=button.dataset.size;
      $('#size-controls').querySelectorAll('button').forEach(b=>b.classList.toggle('active',b===button));
      drawCards();
    }));
    $('#brand-filter').addEventListener('change',e=>{app.brand=e.target.value;drawCards();});
    $('#sort-filter').addEventListener('change',e=>{app.sort=e.target.value;drawCards();});
    render();fetchSavedData();setInterval(fetchSavedData,120000);
  }
  document.addEventListener('DOMContentLoaded',init);
})();
